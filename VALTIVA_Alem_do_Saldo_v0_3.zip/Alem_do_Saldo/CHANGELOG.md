# Histórico de mudanças · VALTIVA

## v0.3 · 28/10/2026 — Primeira versão de experiência imersiva

### Implementado
- Menu principal com identidade própria, cenografia pixel art existente e seleção de 2–6 jogadores.
- Jogo em tela cheia a partir de uma ação do usuário, com fallback para página inteira; sem iframe ou barra lateral fixa.
- HUD compacto com caixa e reserva; painel secundário com dívidas, bem-estar, aprendizagem e minimapa.
- Canvas redimensionável sem distorcer sprites; suporte a tela vertical e horizontal.
- Mapa ampliado derivado do minimapa, com localização, missão e banco.
- Pausa, atalhos, controles mobile, indicação de distância para a missão.
- Tela intermediária de consequência da escolha.
- Etapa final para organizar reserva e dívidas antes do resultado, preservando o sentido educativo da meta.
- Compatibilidade com a chave de armazenamento local da v0.2.
- README, manual, defesa matemática, histórico de prompts e registro de testes.

### Mantido da v0.2
- Mapa de Vila Aurora e elementos pixel art preexistentes.
- Seis capítulos e seus cálculos de porcentagens e juros.
- Sistema financeiro, armazenamento local e cooperativo por turnos no mesmo dispositivo.

### Não implementado nesta versão
- Novo tileset profissional, interiores de edifícios e rotinas de NPCs.
- Missões novas, consequências com ramificações persistentes e minijogos matemáticos integrados às decisões.
- Multiplayer em computadores diferentes, perfis, backend ou nuvem.
- Trilha original e áudio ambiental contínuo.
- Teste presencial que confirme partidas de 15 a 30 minutos.

### Próxima etapa sugerida: v0.4
Transformação da cidade com arte consistente e pontos interativos; aprofundamento dos diálogos; protótipo de desafios de cálculo durante as decisões; observação e teste com estudantes.
