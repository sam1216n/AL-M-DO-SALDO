# Ficha de Defesa Matemática · Além do Saldo v0.3

**Tema:** Educação Financeira e Endividamento. **Objetivo:** usar cálculos matemáticos para compreender consequências de decisões em uma simulação de seis meses.

**1. Porcentagem e descontos.** Na missão do mercado, um tênis de R$ 120 com 25% de desconto fica: `120 × (1 − 0,25) = R$ 90`. No café, um item de R$ 150 com 20% de desconto custa `150 × 0,80 = R$ 120`. O cálculo ajuda a comparar preços e identificar ofertas.

**2. Juros simples.** Fórmulas: `J = C × i × t` e `M = C + J`. Na oficina, uma dívida de R$ 100 a 10% ao mês por dois meses resulta em `J = 100 × 0,10 × 2 = R$ 20`; montante **R$ 120**.

**3. Juros compostos.** Fórmula: `M = C × (1 + i)^t`. No capítulo do banco, R$ 200 a 5% ao mês por dois meses resultam em `M = 200 × 1,05² = R$ 220,50`. Na mecânica principal, dívidas pendentes aumentam **5% ao passar de um mês para o seguinte**, até o quinto avanço mensal; valores são arredondados para centavos.

**4. Fluxo de caixa e reserva.** Em cada novo mês após o primeiro, o personagem recebe R$ 240 e paga R$ 135 em despesas essenciais, produzindo entrada líquida de **R$ 105**, antes de outras escolhas. O jogador decide quanto transferir para a reserva e quanto destinar ao pagamento de dívidas. No desafio da biblioteca, `380 − 240 = R$ 140`.

**5. Regras verificáveis de vitória.** Após seis missões, são necessárias simultaneamente `reserva ≥ R$ 250`, `dívida ≤ R$ 250` e `bem-estar ≥ 35`. Antes do resultado, o grupo pode fazer transferências finais no banco. O saldo disponível não conta como reserva até ser efetivamente transferido.

**Limitações do modelo:** todos os valores são hipotéticos, a economia é simplificada e os pontos de bem-estar não são medidas clínicas. A matemática pretende apoiar a reflexão, não representar contratos de crédito reais.
