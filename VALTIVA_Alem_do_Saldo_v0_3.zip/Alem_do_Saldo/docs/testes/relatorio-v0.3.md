# Registro técnico de testes · v0.3

**Data:** 28/10/2026. **Ambiente:** Chromium headless + Playwright em ambiente de desenvolvimento; HTML/CSS/JS e PNGs do projeto foram carregados em uma página de teste. **Método:** smoke test automatizado, não substitui playtest presencial.

| Teste | Resolução | Resultado |
|---|---|---|
| Menu e abertura | 1440×900 | OK, screenshot |
| Jogar em tela cheia | 1440×900 | OK, API de tela cheia aceita no teste |
| Banco, mapa gráfico, painel, pausa | 1440×900 | OK |
| Concluir os seis capítulos (atalhos internos de QA para localizar NPC) | 1440×900 | OK |
| Última etapa de planejamento | 1440×900 | OK |
| Condição de vitória após transferências finais à reserva | 1440×900 | OK |
| Abertura / HUD / banco / mapa / pausa | 390×844 | OK |
| Abertura / HUD / banco / mapa / pausa | 844×390 | OK |
| Erros capturados no console durante esses percursos | Todas | Nenhum |

**Observação:** para executar a campanha inteira de forma automatizada, o teste usou uma instrumentação temporária, **não incluída na versão final**, que reposiciona o personagem junto ao NPC da missão. Isso verifica o fluxo, mas não verifica tempo de exploração, sensação de controle, bugs de colisão ou clareza para um jogador humano. Testes de 15–30 minutos, feedback de colegas e equilíbrio econômico são pendências da v0.4.

**Capturas:** `docs/capturas/01-abertura-desktop.png`, `02-jogo-desktop.png`, `03-jogo-celular.png`.

**Problema corrigido no teste:** quando o elemento de tela cheia era apenas o aplicativo e o diálogo estava fora dele, o Canvas encobria os controles do diálogo. A tela cheia passou a incluir o documento HTML, mantendo a camada modal clicável.
