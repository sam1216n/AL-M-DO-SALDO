(function(){
'use strict';
const world=window.AlemWorld;
const $=id=>document.getElementById(id);
const canvas=$('gameCanvas'),ctx=canvas.getContext('2d',{alpha:false}),mini=$('miniMap'),mx=mini.getContext('2d');
ctx.imageSmoothingEnabled=false;mx.imageSmoothingEnabled=false;
let VIEW_W=canvas.width,VIEW_H=canvas.height;const S=world.SIZE;
function resizeStage(){
 const w=window.innerWidth,h=window.innerHeight;
 // Pixels lógicos: câmera adapta o enquadramento, sem esticar as imagens do mundo.
 const zoom=clamp(Math.min(w/900,h/560),.74,2.25);
 VIEW_W=Math.max(320,Math.round(w/zoom));VIEW_H=Math.max(260,Math.round(h/zoom));
 canvas.width=VIEW_W;canvas.height=VIEW_H;ctx.imageSmoothingEnabled=false;
}
window.addEventListener('resize',resizeStage);window.addEventListener('orientationchange',resizeStage);
const money=n=>new Intl.NumberFormat('pt-BR',{style:'currency',currency:'BRL',maximumFractionDigits:2}).format(n);
const round=n=>Math.round((n+Number.EPSILON)*100)/100;
const clamp=(a,lo,hi)=>Math.max(lo,Math.min(hi,a));
const STORAGE='alem_saldo_alpha_v1'; // mantém compatibilidade com partidas antigas
const assets={};
const assetNames=['tiles','characters','market','bank','school','cafe','workshop','home','park','tree0','tree1','tree2','bench','lamp','flowerbed','fountain','crate','scooter','mailbox'];
for(const name of assetNames){const im=new Image();im.src='assets/'+name+'.png';assets[name]=im;}
let state,started=false,modalOpen=true,soundOn=false,audioCtx=null,selectedParty=2;
const keys=Object.create(null);
let last=0,anim=0,camera={x:0,y:0},messageTimer=null,autoSaveEnabled=true;
let tracking=[...Array(240)].map(()=>({x:34*S,y:28*S}));
const missions=[
 {name:'A promoção relâmpago',desc:'Encontre Lia no mercado e decida como gastar sua mesada.',person:0,location:'Mercado do Sol',icon:'🛒',talk:'Chegou uma oferta especial hoje. Mas vale a pena gastar agora, com a matrícula do curso chegando?',choices:[
  {name:'Comprar só o necessário',desc:'Você paga à vista e evita gastos por impulso.',effect:{cash:-45,wellness:3,learning:5},badge:'− R$ 45'},
  {name:'Guardar e comparar preços',desc:'Reserva parte do dinheiro para o futuro.',effect:{cash:-70,savings:70,learning:8},badge:'+ R$ 70 na reserva'},
  {name:'Parcelar compras extras',desc:'Você leva mais produtos, mas assume uma obrigação futura.',effect:{debt:180,wellness:4,learning:-2},badge:'+ R$ 180 em dívida'}],
 quiz:{q:'Um tênis custa R$ 120 e está com 25% de desconto. Qual é o preço final?',options:['R$ 100','R$ 90','R$ 95'],answer:1,work:'25% de 120 = 30. Preço final: 120 − 30 = R$ 90.'}},
 {name:'O conserto inesperado',desc:'Fale com Bento na oficina. Um imprevisto apareceu.',person:1,location:'Oficina do Bento',icon:'🔧',talk:'Sem o celular, fica difícil acompanhar o trabalho. Posso fazer o reparo hoje ou você prefere economizar?',choices:[
  {name:'Pagar o conserto à vista',desc:'Resolve agora, sem juros futuros.',effect:{cash:-100,wellness:7},badge:'− R$ 100'},
  {name:'Buscar uma solução mais barata',desc:'O conserto leva mais tempo, mas custa menos.',effect:{cash:-40,wellness:2,learning:6},badge:'− R$ 40'},
  {name:'Pagar no crédito',desc:'Conserta agora e fica devendo o serviço.',effect:{debt:135,wellness:5},badge:'+ R$ 135 em dívida'}],
 quiz:{q:'Uma dívida de R$ 100 tem juros SIMPLES de 10% ao mês por 2 meses. Qual o total?',options:['R$ 120','R$ 121','R$ 110'],answer:0,work:'J = 100 × 0,10 × 2 = R$ 20. Montante = 100 + 20 = R$ 120.'}},
 {name:'Crédito fácil?',desc:'Ravi, no banco, apresenta uma oferta de empréstimo.',person:2,location:'Banco Aurora',icon:'🏦',talk:'O crédito resolve algumas situações, mas a taxa também participa da decisão. Vamos olhar os números?',choices:[
  {name:'Dispensar crédito e guardar',desc:'Você fortalece sua reserva, sem contratar juros.',effect:{cash:-70,savings:70,learning:6},badge:'+ R$ 70 na reserva'},
  {name:'Aceitar o empréstimo',desc:'Recebe R$ 150. A dívida crescerá 5% a cada mês em que não for paga.',effect:{cash:150,debt:150,wellness:3},badge:'+ R$ 150 em dívida'},
  {name:'Separar dinheiro para o curso',desc:'Você guarda R$ 85 do caixa e mantém o objetivo em mente.',effect:{cash:-85,savings:85,learning:7},badge:'+ R$ 85 na reserva'}],
 quiz:{q:'R$ 200 com juros COMPOSTOS de 5% ao mês por 2 meses vira quanto?',options:['R$ 220,00','R$ 220,50','R$ 230,00'],answer:1,work:'M = 200 × (1 + 0,05)² = 200 × 1,1025 = R$ 220,50.'}},
 {name:'O encontro no café',desc:'Maya aguarda você no café para planejar uma comemoração.',person:3,location:'Café da Praça',icon:'☕',talk:'Queria reunir a turma neste fim de semana. Você topa ajudar sem perder de vista o seu curso?',choices:[
  {name:'Fazer um presente criativo',desc:'Você gasta pouco e valoriza a amizade.',effect:{cash:-25,wellness:8,learning:5},badge:'− R$ 25'},
  {name:'Comprar um presente caro',desc:'Gasta mais do que o planejado.',effect:{cash:-120,wellness:3},badge:'− R$ 120'},
  {name:'Comemorar e poupar também',desc:'Equilibra a comemoração com uma reserva.',effect:{cash:-60,savings:60,wellness:4,learning:5},badge:'+ R$ 60 na reserva'}],
 quiz:{q:'Um produto de R$ 150 recebe 20% de desconto. Quanto você paga?',options:['R$ 130','R$ 120','R$ 125'],answer:1,work:'20% de 150 = R$ 30. Você paga 150 − 30 = R$ 120.'}},
 {name:'Investir em você',desc:'Encontre Sol na biblioteca e pense no futuro.',person:4,location:'Biblioteca',icon:'📚',talk:'Encontrei um curso que tem tudo a ver com você. Só falta pensar em como chegar até lá.',choices:[
  {name:'Fortalecer a reserva',desc:'Guarda R$ 90 e aproxima você da matrícula.',effect:{cash:-90,savings:90,learning:8},badge:'+ R$ 90 na reserva'},
  {name:'Fazer um trabalho extra',desc:'Aumenta o caixa, mas toma tempo de descanso.',effect:{cash:40,wellness:-4,learning:5},badge:'+ R$ 40'},
  {name:'Comprar material de estudo',desc:'Investe em aprendizado, sem comprometer a saúde.',effect:{cash:-40,learning:12,wellness:3},badge:'− R$ 40'}],
 quiz:{q:'Você recebe R$ 380 e gasta R$ 240 com despesas. Quanto sobra para planejar?',options:['R$ 140','R$ 120','R$ 160'],answer:0,work:'380 − 240 = R$ 140 disponíveis para poupar ou outros objetivos.'}},
 {name:'Seu próximo passo',desc:'Procure a professora Ana na escola e conclua sua jornada.',person:5,location:'Escola Municipal',icon:'🎓',talk:'A inscrição do curso está quase fechando. Antes de decidir, que tal olhar para tudo o que você construiu?',choices:[
  {name:'Priorizar a matrícula',desc:'Direciona R$ 100 do caixa para sua reserva.',effect:{cash:-100,savings:100,wellness:5},badge:'+ R$ 100 na reserva'},
  {name:'Fazer um último trabalho extra',desc:'Ganha mais, mas perde um pouco de descanso.',effect:{cash:90,wellness:-8,learning:4},badge:'+ R$ 90'},
  {name:'Poupar e descansar',desc:'Guarda R$ 40 e cuida do bem-estar.',effect:{cash:-40,savings:40,wellness:12},badge:'+ R$ 40 na reserva'}],
 quiz:{q:'R$ 300 a juros SIMPLES de 8% ao mês por 2 meses geram qual montante?',options:['R$ 348','R$ 350','R$ 324'],answer:0,work:'J = 300 × 0,08 × 2 = R$ 48. Montante final = R$ 348.'}}
];
function blank(party=2){return {party,stage:0,cash:260,savings:0,debt:0,wellness:70,learning:0,correct:0,x:34*S,y:28*S,dir:0,logs:[],month:1,completed:false,bankUses:0,phase:'explore',lastQuizRight:null,lastChoiceIndex:null};}
function save(){if(!started||!autoSaveEnabled)return;try{localStorage.setItem(STORAGE,JSON.stringify(state))}catch{}}
function stored(){try{
 const raw=localStorage.getItem(STORAGE);if(!raw)return null;
 const obj=JSON.parse(raw);
 if(!obj||typeof obj!=='object'||!Number.isInteger(obj.stage)||obj.stage<0||obj.stage>6||!Number.isInteger(obj.party)||obj.party<2||obj.party>6)return null;
 for(const key of ['cash','savings','debt','wellness','learning','correct','x','y'])if(!Number.isFinite(obj[key]))return null;
 if(!Array.isArray(obj.logs)||obj.x<0||obj.y<0||obj.x>world.W*S||obj.y>world.H*S)return null;
 obj.phase=['explore','outcome','quiz','feedback','final-plan'].includes(obj.phase)?obj.phase:'explore';
 obj.logs=obj.logs.filter(t=>typeof t==='string').slice(-120);obj.correct=clamp(obj.correct,0,6);
 return obj;
 }catch{return null;}}
function openModal(html){modalOpen=true;$('modalLayer').style.display='flex';$('modal').innerHTML=html;for(const k in keys)keys[k]=false;}
function closeModal(){modalOpen=false;$('modalLayer').style.display='none';$('modal').innerHTML='';}
function modalTitle(s){return String(s).replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('>','&gt;')}
function toast(text){$('toast').textContent=text;$('toast').classList.add('visible');clearTimeout(messageTimer);messageTimer=setTimeout(()=>$('toast').classList.remove('visible'),3000)}
function tone(freq=520,duration=.07,type='sine'){if(!soundOn)return;try{audioCtx=audioCtx||new (window.AudioContext||window.webkitAudioContext)();if(audioCtx.state==='suspended')audioCtx.resume();const osc=audioCtx.createOscillator(),gain=audioCtx.createGain();osc.type=type;osc.frequency.value=freq;gain.gain.setValueAtTime(.035,audioCtx.currentTime);gain.gain.exponentialRampToValueAtTime(.001,audioCtx.currentTime+duration);osc.connect(gain).connect(audioCtx.destination);osc.start();osc.stop(audioCtx.currentTime+duration)}catch{}}
function requestGameFullscreen(){
 const node=document.documentElement;
 if(document.fullscreenElement||!node.requestFullscreen)return;
 try{const p=node.requestFullscreen({navigationUI:'hide'});if(p&&p.catch)p.catch(()=>toast('O jogo já está ocupando a página. Você também pode usar F11.'));}catch{}
}
function toggleFullscreen(){
 if(document.fullscreenElement){document.exitFullscreen().catch(()=>{});}else requestGameFullscreen();
}
document.addEventListener('fullscreenchange',()=>{
 $('fullscreenBtn').textContent=document.fullscreenElement?'⛶':'⛶';
 $('fullscreenBtn').setAttribute('aria-label',document.fullscreenElement?'Sair da tela cheia':'Entrar em tela cheia');
 resizeStage();
});
function beginPresentation(){
 $('titleScreen').classList.add('hidden');$('gameUI').classList.remove('hidden');
 $('statusPanel').classList.add('hidden');$('modalLayer').style.display='none';
}
function intro(){
 const saved=stored();
 state=blank(selectedParty);started=false;modalOpen=true;camera={x:0,y:0};
 $('gameUI').classList.add('hidden');$('titleScreen').classList.remove('hidden');
 $('modalLayer').style.display='none';
 $('continueGame').hidden=!saved;
 $('partySelect').querySelectorAll('button').forEach(b=>b.classList.toggle('selected',Number(b.dataset.party)===selectedParty));
 $('partySelect').querySelectorAll('button').forEach(b=>b.onclick=()=>{
  selectedParty=Number(b.dataset.party);
  $('partySelect').querySelectorAll('button').forEach(x=>x.classList.toggle('selected',x===b));
 });
 $('startGame').onclick=()=>{requestGameFullscreen();startGame(selectedParty)};
 $('continueGame').onclick=()=>{
  requestGameFullscreen();if(!saved)return;
  state=saved;started=true;tracking=[...Array(240)].map(()=>({x:state.x,y:state.y}));beginPresentation();updateUI();
  if(state.completed){endGame();return;}
  if(state.phase==='final-plan'){showFinalPlan();return;}
  if(state.phase==='outcome'){showDecisionOutcome();return;}
  if(state.phase==='quiz'){showQuiz();return;}
  if(state.phase==='feedback'){showQuizFeedback(state.lastQuizRight===true);return;}
  closeModal();toast('Partida recuperada. Boa aventura!');
 };
 $('titleHelpBtn').onclick=showHelp;
}
function startGame(n){
 state=blank(n);started=true;tracking=[...Array(240)].map(()=>({x:state.x,y:state.y}));
 beginPresentation();updateUI();save();closeModal();
 toast('Primeiro destino: Mercado do Sol. Procure Lia!');tone(700,.13);
}
function toggleStatus(force){
 if(!started||modalOpen)return;
 const el=$('statusPanel');el.classList.toggle('hidden',force===undefined?!el.classList.contains('hidden'):!force);
}
function showPause(){
 if(!started||state.completed){return;}
 if(state.phase==='final-plan'){showFinalPlan();return;}
 if(state.phase!=='explore')return;
 openModal(`<span class="modal-eyebrow">VALTIVA · ALÉM DO SALDO</span><h2>Uma pausa na jornada.</h2><p>O mundo de Vila Aurora fica aqui esperando. Sua partida está salva neste navegador.</p><div class="button-line"><button class="primary-button" id="resumeGame">Continuar jogando →</button><button class="secondary-button" id="pauseMap">Consultar mapa</button><button class="secondary-button" id="pauseHelp">Como jogar</button></div>`);
 $('resumeGame').onclick=closeModal;$('pauseMap').onclick=showMap;$('pauseHelp').onclick=showHelp;
}
function updateUI(){if(!state)return;const mission=missions[Math.min(state.stage,5)];$('cashValue').textContent=money(state.cash);$('savingsValue').textContent=money(state.savings);$('cashDetail').textContent=money(state.cash);$('savingsDetail').textContent=money(state.savings);$('debtValue').textContent=money(state.debt);$('wellnessValue').textContent=Math.round(state.wellness)+' / 100';$('wellnessBar').style.width=clamp(state.wellness,0,100)+'%';$('stageBadge').innerHTML=String(Math.min(state.stage+1,6)).padStart(2,'0')+' <small>/ 06</small>';$('monthTop').textContent='MÊS '+Math.min(state.stage+1,6)+' / 6';$('playerTag').textContent='Jogador '+(state.stage%state.party+1)+' de '+state.party;$('missionName').textContent=mission.name;$('missionDesc').textContent=mission.desc;$('targetPill').textContent='◎ '+mission.location;$('missionProgress').textContent=String(Math.min(state.stage+1,6)).padStart(2,'0')+' / 06';$('progressFill').style.width=(100*state.stage/6)+'%';const tip=learningTopics[Math.min(state.stage,5)];$('learningTitle').textContent=tip.title;$('learningText').textContent=tip.summary;}
const learningTopics=[
 {title:'Consumo consciente',summary:'Comparar preços e reconhecer necessidades ajudam a evitar gastos por impulso.',detail:'Uma promoção só representa economia quando o produto realmente é necessário. Antes de comprar, compare preço, qualidade e impacto no orçamento.'},
 {title:'Juros simples',summary:'Nos juros simples, o valor dos juros é calculado sobre o capital inicial.',detail:'Fórmula: J = C × i × t. Se R$ 100 rendem 10% ao mês durante 2 meses, J = 100 × 0,10 × 2 = R$ 20. O total é R$ 120.'},
 {title:'Juros compostos',summary:'Nos juros compostos, os juros passam a incidir também sobre os juros anteriores.',detail:'Fórmula: M = C × (1 + i)^t. Com R$ 200, taxa de 5% ao mês e 2 meses: M = 200 × 1,05² = R$ 220,50.'},
 {title:'Descontos e porcentagens',summary:'Uma porcentagem mostra uma parte de cada cem unidades.',detail:'Se algo custa R$ 150 e recebe desconto de 20%, você economiza R$ 30 e paga R$ 120. Atenção: descontos sucessivos não se somam diretamente.'},
 {title:'Orçamento e reserva',summary:'Entender a diferença entre receita e despesa facilita o planejamento.',detail:'Saldo do mês = receitas − despesas. Uma reserva de emergência ajuda a enfrentar imprevistos; o valor adequado depende do contexto de cada pessoa.'},
 {title:'Equilíbrio e bem-estar',summary:'Organização financeira também envolve descanso, estudo e decisões possíveis.',detail:'Planejar significa avaliar objetivos, gastos e tempo. O indicador de bem-estar do jogo é simbólico e não corresponde a um diagnóstico de saúde.'}
];
function showLearning(){if(!started){showHelp();return;}const tip=learningTopics[Math.min(state.stage,5)];openModal(`<button class="close-x" id="closeLearning" aria-label="Fechar">×</button><span class="modal-eyebrow">APRENDER COM A VALTIVA · CONCEITO ${Math.min(state.stage+1,6)} / 6</span><h2>${tip.title}</h2><p>${tip.detail}</p><div class="intro-summary"><strong>Como usar na partida:</strong> observe o desafio deste capítulo e escolha com base no orçamento disponível, não apenas na recompensa imediata.</div><button class="primary-button" id="dismissLearning">Voltar ao jogo →</button>`);$('closeLearning').onclick=$('dismissLearning').onclick=closeModal;}
function activeNPC(){return world.people[missions[Math.min(state.stage,5)].person]}
function nearestNPC(){if(!state)return null;let best=null,d=Infinity;for(const p of world.people){const distance=Math.hypot(state.x-p.x*S,state.y-p.y*S);if(distance<74&&distance<d){best=p;d=distance}}return best}
function interact(){if(!started||modalOpen||state.completed)return;const p=nearestNPC();if(!p){toast('Chegue perto de um personagem e pressione E.');return;}tone(640,.065);if(p.bank){showBank();return;}if(p.mission===state.stage){showMission();return;}if(p.mission!==undefined){showNPC(p);return;}showNPC(p);}
function showNPC(p){openModal(`<button class="close-x" id="closeTalk" aria-label="Fechar">×</button><span class="modal-eyebrow">CONVERSA EM VILA AURORA</span><h2>${p.name}</h2><p>${p.flavor||'Oi! Minha missão aparece em outro momento da sua jornada. Continue seguindo o marcador dourado.'}</p><button class="primary-button" id="dismissTalk">Continuar ▶</button>`);$('closeTalk').onclick=$('dismissTalk').onclick=closeModal;}
function affordable(e){return state.cash+(e.cash||0)>=-0.001 && state.savings+(e.savings||0)>=-0.001}
function showMission(){if(state.phase!=='explore')return;const m=missions[state.stage];openModal(`<button class="close-x" id="closeQuest" aria-label="Fechar">×</button><span class="modal-eyebrow">CAPÍTULO ${state.stage+1} DE 6 · ${m.location}</span><h2>${m.icon} ${m.name}</h2><p><b>${world.people[m.person].name}:</b> ${m.talk}</p><span class="modal-eyebrow">QUAL CAMINHO VOCÊ ESCOLHE?</span><div id="choices">${m.choices.map((c,i)=>`<button class="choice" data-choice="${i}" ${affordable(c.effect)?'':'disabled'}><div class="choice-header"><span>${i+1}. ${c.name}</span><span class="choose-badge">${c.badge}</span></div><p>${c.desc}${affordable(c.effect)?'':' · Saldo insuficiente.'}</p></button>`).join('')}</div><p class="notice">Conversem em equipe. A vez atual é do jogador ${state.stage%state.party+1}.</p>`);$('closeQuest').onclick=closeModal;$('choices').querySelectorAll('button').forEach(b=>b.onclick=()=>selectChoice(Number(b.dataset.choice)));}
function selectChoice(idx){if(state.phase!=='explore')return;const m=missions[state.stage],c=m.choices[idx];if(!c||!affordable(c.effect))return;for(const k of ['cash','savings','debt','wellness','learning'])state[k]=round((state[k]||0)+(c.effect[k]||0));state.wellness=clamp(state.wellness,0,100);state.debt=Math.max(0,state.debt);state.logs.push(`Mês ${state.stage+1}: ${c.name}`);state.phase='outcome';state.lastChoiceIndex=idx;save();tone(760,.12);showDecisionOutcome();}
function showDecisionOutcome(){
 if(state.phase!=='outcome')return;
 const m=missions[state.stage],c=m.choices[state.lastChoiceIndex];
 if(!c){state.phase='quiz';save();showQuiz();return;}
 const sign=(n)=>n>0?'+':'−';
 const labels={cash:'CAIXA',savings:'RESERVA',debt:'DÍVIDAS',wellness:'BEM-ESTAR'};
 const rows=Object.entries(labels).filter(([k])=>c.effect[k]!==undefined&&c.effect[k]!==0).map(([k,label])=>`<div><span>${label}</span><strong>${sign(c.effect[k])}${k==='wellness'?Math.abs(c.effect[k])+' pontos':money(Math.abs(c.effect[k]))}</strong></div>`).join('');
 openModal(`<span class="modal-eyebrow">CAPÍTULO ${state.stage+1} · SUA ESCOLHA TEM CONSEQUÊNCIAS</span><h2>${c.name}</h2><p>${c.desc}</p><div class="mini-table">${rows}</div><div class="intro-summary"><b>O que acontece agora?</b> Seu orçamento foi atualizado. Nem toda decisão tem um caminho perfeito; o importante é perceber custos, benefícios e consequências.</div><button class="primary-button" id="proceedMath">Analisar os números →</button>`);
 $('proceedMath').onclick=()=>{state.phase='quiz';save();showQuiz()};
}
function showQuiz(){const m=missions[state.stage];openModal(`<span class="modal-eyebrow">DESAFIO MATEMÁTICO • MÊS ${state.stage+1}</span><h2>Hora de fazer as contas!</h2><p>Decisão registrada. Agora resolva este desafio para ganhar <b>R$ 30 extras</b> para seu caixa. Se errar, receberá a explicação e poderá continuar.</p><div class="math-strip">${m.quiz.q}</div><div id="answers">${m.quiz.options.map((opt,i)=>`<button class="choice" data-answer="${i}"><div class="choice-header"><span>${String.fromCharCode(65+i)}. ${opt}</span><span>→</span></div></button>`).join('')}</div>`);$('answers').querySelectorAll('button').forEach(b=>b.onclick=()=>answerQuiz(Number(b.dataset.answer)));}
const scienceNotes=[
"O consumo por impulso pode gerar pressão financeira. Planejar ajuda a reduzir preocupações, mas nem toda dificuldade econômica depende das escolhas individuais.",
"Imprevistos financeiros podem aumentar o estresse. Pausas, apoio social e um plano realista podem ajudar no enfrentamento.",
"Dívidas e incertezas podem afetar o sono e a concentração. O marcador de bem-estar do jogo é simbólico, não um diagnóstico.",
"Laços sociais e lazer também importam para a qualidade de vida. Uma atividade significativa não precisa ser cara.",
"Estudar, descansar e cuidar da rotina fazem parte de um projeto de vida sustentável.",
"Equilibrar trabalho, descanso e estudo ajuda a pensar em objetivos de longo prazo sem negligenciar a saúde."
];
function answerQuiz(idx){
 if(state.phase!=='quiz')return;
 const m=missions[state.stage],right=idx===m.quiz.answer;
 if(right){state.cash=round(state.cash+30);state.learning+=15;state.correct++;tone(900,.15);setTimeout(()=>tone(1200,.18),100)}
 else{state.learning+=4;tone(310,.13,'triangle')}
 state.logs.push(`Desafio ${state.stage+1}: ${right?'acertou':'aprendeu com o erro'}`);
 state.phase='feedback';state.lastQuizRight=right;save();showQuizFeedback(right);
}
function showQuizFeedback(right){
 const m=missions[state.stage];
 openModal(`<span class="modal-eyebrow">${right?'RESPOSTA CORRETA':'VAMOS ENTENDER'}</span><h2>${right?'✦ Mandou bem!':'Uma boa chance de aprender.'}</h2><p>${right?'Você aplicou a Matemática e ganhou R$ 30 para o caixa do grupo.':'Errar faz parte do aprendizado. Veja como chegar ao resultado correto:'}</p><div class="feedback ${right?'':'warning'}"><strong>Resolução:</strong> ${m.quiz.work}</div><div class="intro-summary"><b>🌿 Conexão com Ciências da Natureza:</b> ${scienceNotes[state.stage]}</div><div class="mini-table"><div><span>Caixa atual</span><strong>${money(state.cash)}</strong></div><div><span>Reserva guardada</span><strong>${money(state.savings)}</strong></div><div><span>Dívidas</span><strong>${money(state.debt)}</strong></div></div><button class="primary-button" id="nextMonth">${state.stage===5?'Ver meu resultado →':'Ir para o próximo mês →'}</button>`);
 updateUI();$('nextMonth').onclick=advanceMonth;
}
function advanceMonth(){if(state.phase!=='feedback')return;state.phase='explore';state.lastQuizRight=null;state.lastChoiceIndex=null;state.stage++;
 if(state.stage>=6){state.phase='final-plan';save();updateUI();showFinalPlan();return;}
 const oldDebt=state.debt;
 state.cash=round(state.cash+105);state.debt=round(state.debt*1.05);state.wellness=clamp(state.wellness+(state.debt>250?-4:2),0,100);
 state.month=state.stage+1;state.logs.push(`Início do mês ${state.month}: renda R$ 240, despesas essenciais R$ 135; juros 5% sobre dívida anterior ${money(oldDebt)}.`);
 updateUI();save();closeModal();toast('Novo mês: + R$ 240 de renda, − R$ 135 em despesas.');}
function showBank(){const maxPay=Math.min(100,state.debt,state.cash);openModal(`<button class="close-x" id="closeBank" aria-label="Fechar">×</button><span class="modal-eyebrow">BANCO AURORA • APLICATIVO DE CONTA</span><h2>Organize seu dinheiro.</h2><p>Depósitos separam dinheiro do dia a dia. Pagamentos reduzem a dívida. Os juros de 5% por mês são aplicados sobre as dívidas fictícias entre os capítulos.</p><div class="mini-table"><div><span>Disponível</span><strong>${money(state.cash)}</strong></div><div><span>Reserva guardada</span><strong>${money(state.savings)}</strong></div><div><span>Dívidas a pagar</span><strong>${money(state.debt)}</strong></div></div><span class="modal-eyebrow">OPERAÇÕES</span><div id="bankOptions"><button class="choice" data-bank="save50" ${state.cash<50?'disabled':''}><div class="choice-header"><span>🏦 Guardar R$ 50</span><span>→</span></div><p>Transfere do disponível para a reserva.</p></button><button class="choice" data-bank="save100" ${state.cash<100?'disabled':''}><div class="choice-header"><span>🏦 Guardar R$ 100</span><span>→</span></div><p>Reserva mais dinheiro para seu objetivo.</p></button><button class="choice" data-bank="withdraw" ${state.savings<50?'disabled':''}><div class="choice-header"><span>↩ Retirar R$ 50 da reserva</span><span>→</span></div><p>Devolve dinheiro ao saldo de uso diário.</p></button><button class="choice" data-bank="pay" ${maxPay<.01?'disabled':''}><div class="choice-header"><span>↓ Pagar até R$ 100 da dívida</span><span>${money(maxPay)}</span></div><p>Reduz a dívida pelo valor efetivamente pago.</p></button></div><p class="notice">Valores simulados e sem orientação financeira personalizada.</p>`);$('closeBank').onclick=()=>state.phase==='final-plan'?showFinalPlan():closeModal();$('bankOptions').querySelectorAll('button').forEach(b=>b.onclick=()=>bankAction(b.dataset.bank));}
function bankAction(action){let amt=0,label='';if(action==='save50'||action==='save100'){amt=action==='save50'?50:100;if(state.cash<amt)return;state.cash=round(state.cash-amt);state.savings=round(state.savings+amt);label='Você guardou '+money(amt)+'.'}
 else if(action==='withdraw'){amt=50;if(state.savings<amt)return;state.cash=round(state.cash+amt);state.savings=round(state.savings-amt);label='Você retirou '+money(amt)+' da reserva.'}
 else if(action==='pay'){amt=Math.min(100,state.cash,state.debt);if(amt<.01)return;state.cash=round(state.cash-amt);state.debt=round(state.debt-amt);label='Você reduziu sua dívida em '+money(amt)+'.'}
 state.bankUses++;state.logs.push('Banco: '+label);tone(820,.09);updateUI();save();showBank();toast(label);}
function showFinalPlan(){
 if(!state||state.phase!=='final-plan')return;
 const enough=state.savings>=250&&state.debt<=250&&state.wellness>=35;
 openModal(`<span class="modal-eyebrow">EPÍLOGO · SEIS MESES DE ESCOLHAS</span><h2>Antes do próximo passo...</h2><p>Seu curso está logo ali. Falta apenas conferir o dinheiro reservado, as dívidas e o bem-estar. Essa é sua última oportunidade de organizar o orçamento.</p><div class="mini-table"><div><span>Disponível para organizar</span><strong>${money(state.cash)}</strong></div><div><span>Reserva / meta de R$ 250</span><strong>${money(state.savings)}</strong></div><div><span>Dívidas / limite de R$ 250</span><strong>${money(state.debt)}</strong></div><div><span>Bem-estar / mínimo 35</span><strong>${Math.round(state.wellness)} / 100</strong></div></div><div class="intro-summary">${enough?'Seu planejamento já cumpre os três objetivos. Você pode concluir a jornada.':'Você pode transferir dinheiro à reserva ou quitar dívidas antes do encerramento. Seu saldo disponível não conta automaticamente como reserva.'}</div><div class="button-line"><button class="primary-button" id="finishJourney">Concluir jornada →</button><button class="secondary-button" id="lastBank">Organizar no banco</button></div>`);
 $('finishJourney').onclick=()=>{state.completed=true;state.phase='explore';save();updateUI();endGame()};
 $('lastBank').onclick=showBank;
}
function endGame(){const won=state.savings>=250&&state.debt<=250&&state.wellness>=35;const reasons=[state.savings<250?'Reserva abaixo de R$ 250':null,state.debt>250?'Dívida acima de R$ 250':null,state.wellness<35?'Bem-estar abaixo de 35':null].filter(Boolean);openModal(`<div class="hero-mark">${won?'🎓':'🧭'}</div><span class="modal-eyebrow">FIM DE CAMPANHA · 6 MESES</span><h2>${won?'Um futuro em construção!':'Toda escolha ensina.'}</h2><p>${won?'Sua equipe atingiu o objetivo do curso com organização financeira e cuidado com o bem-estar. Vocês venceram!':'Sua equipe terminou os seis capítulos, mas ainda há pontos para melhorar. O mais importante é entender as escolhas e tentar novas estratégias.'}</p><div class="mini-table"><div><span>Economia acumulada</span><strong>${money(state.savings)} / R$ 250</strong></div><div><span>Dívidas finais</span><strong>${money(state.debt)} / R$ 250</strong></div><div><span>Bem-estar</span><strong>${Math.round(state.wellness)} / 100</strong></div><div><span>Desafios resolvidos</span><strong>${state.correct} / 6</strong></div><div><span>Operações bancárias</span><strong>${state.bankUses}</strong></div></div>${reasons.length?`<div class="feedback warning"><b>Para revisar:</b> ${reasons.join(' · ')}.</div>`:`<div class="feedback"><b>Vitória!</b> Você concluiu o objetivo sem depender apenas da sorte.</div>`}<div class="button-line"><button class="primary-button" id="restartEnd">↻ Tentar outra jornada</button><button class="secondary-button" id="logEnd">Ver minhas escolhas</button></div>`);$('restartEnd').onclick=()=>{try{localStorage.removeItem(STORAGE)}catch{}startGame(state.party)};$('logEnd').onclick=showJournal;}
function showJournal(){if(!state)return;openModal(`<button class="close-x" id="closeJournal">×</button><span class="modal-eyebrow">DIÁRIO DE VIAGEM</span><h2>Suas decisões</h2><p>Veja como o orçamento mudou durante a aventura.</p><div class="mini-table">${state.logs.slice(-30).map((t,i)=>`<div><span style="color:#34545a">${i+1}. ${modalTitle(t)}</span></div>`).join('')||'<div><span>Você ainda não concluiu nenhuma missão.</span></div>'}</div><button class="primary-button" id="dismissJournal">${state.completed?'Voltar aos resultados':'Voltar ao mapa'}</button>`);$('closeJournal').onclick=$('dismissJournal').onclick=()=>{if(state.completed)endGame();else if(state.phase==='final-plan')showFinalPlan();else closeModal()};}
function showHelp(){openModal(`<button class="close-x" id="closeHelp">×</button><span class="modal-eyebrow">GUIA DE VILA AURORA</span><h2>Como jogar</h2><p>O jogo foi pensado para <b>2 a 6 pessoas no mesmo computador ou celular</b>. Um participante decide a cada mês, enquanto os outros podem discutir.</p><div class="rule-grid"><div><b>🕹 Movimentação</b>Setas ou WASD para caminhar. No celular, use o controle virtual.</div><div><b>💬 Interação</b>Pressione E perto de NPCs, ou toque no botão FALAR.</div><div><b>💰 Gestão</b>Aperte B para abrir o banco, guardar, retirar ou pagar dívidas.</div><div><b>🧮 Matemática ativa</b>Responda aos cálculos a cada missão. Respostas corretas premiam planejamento.</div><div><b>✦ Indicador dourado</b>Siga o marcador acima do personagem da missão atual.</div><div><b>🎓 Vitória</b>Reserva ≥ R$ 250; dívida ≤ R$ 250; bem-estar ≥ 35 após seis missões.</div></div><p class="notice" style="margin-top:16px">No início de cada novo mês, entram R$ 240 de renda e saem R$ 135 em despesas essenciais; dívidas remanescentes aumentam 5% ao mês. Jogo de simulação, não uma descrição universal da vida financeira.</p><div class="button-line"><button class="primary-button" id="dismissHelp">Entendi ✓</button>${started?'<button class="secondary-button" id="openJournal">Ver diário</button>':''}</div>`);$('closeHelp').onclick=$('dismissHelp').onclick=()=>{if(started&&state.completed)endGame();else if(started&&state.phase==='final-plan')showFinalPlan();else if(started)closeModal();else intro()};if(started)$('openJournal').onclick=showJournal;}
function showMap(){
 if(!state)return;
 const p=activeNPC();drawMini();
 const mapImage=mini.toDataURL('image/png');
 openModal(`<button class="close-x" id="closeMap" aria-label="Fechar mapa">×</button><span class="modal-eyebrow">CARTOGRAFIA · VILA AURORA</span><h2>Os caminhos da cidade</h2><p>Destino do mês: <b>${missions[Math.min(state.stage,5)].location}</b>. Procure <b>${p.name}</b> e o indicador dourado sobre sua cabeça.</p><img class="map-preview" src="${mapImage}" alt="Mapa da cidade: ponto verde é o jogador, amarelo é a missão e o ponto claro marca o banco"><div class="rule-grid"><div><b>● Verde-água</b>Sua posição no mundo.</div><div><b>● Amarelo</b>Próxima missão.</div><div><b>● Claro</b>Banco Aurora (operações financeiras).</div><div><b>Explore sem pressa</b>Fale com os moradores e encontre os estabelecimentos.</div></div><div class="button-line"><button class="primary-button" id="dismissMap">Voltar a explorar →</button><button class="secondary-button" id="goBank">Abrir banco digital</button></div>`);
 $('closeMap').onclick=$('dismissMap').onclick=()=>state.phase==='final-plan'?showFinalPlan():closeModal();
 $('goBank').onclick=showBank;
}
function drawImage(name,x,y,scale=1){const im=assets[name];if(!im||!im.complete||!im.naturalWidth)return;const w=im.naturalWidth*scale,h=im.naturalHeight*scale;ctx.drawImage(im,Math.round(x-camera.x-w/2),Math.round(y-camera.y-h),Math.round(w),Math.round(h))}
function sprite(person,x,y,dir=0,frame=0,scale=2){const im=assets.characters;if(!im.complete||!im.naturalWidth)return;ctx.drawImage(im,24*(frame%3),32*(person*4+dir),24,32,Math.round(x-camera.x-12*scale),Math.round(y-camera.y-30*scale),24*scale,32*scale);}
function tile(x,y,index){const a=assets.tiles;if(!a.complete||!a.naturalWidth)return;ctx.drawImage(a,index*16,0,16,16,x,y,S+1,S+1)}
function glow(x,y,r,col){let g=ctx.createRadialGradient(x,y,0,x,y,r);g.addColorStop(0,col);g.addColorStop(1,'transparent');ctx.fillStyle=g;ctx.fillRect(x-r,y-r,r*2,r*2)}
function niceLabel(text,x,y,selected=false){ctx.save();ctx.font='bold 13px Trebuchet MS,Arial,sans-serif';const width=ctx.measureText(text).width+26;let left=Math.round(x-width/2),top=Math.round(y-21);ctx.fillStyle=selected?'#f6d58d':'#193c48d9';roundRect(left,top,width,25,7);ctx.fill();ctx.fillStyle=selected?'#2b4951':'#fff4d4';ctx.textAlign='center';ctx.textBaseline='middle';ctx.fillText(text,x,top+13);ctx.restore();}
function roundRect(x,y,w,h,r){ctx.beginPath();ctx.moveTo(x+r,y);ctx.arcTo(x+w,y,x+w,y+h,r);ctx.arcTo(x+w,y+h,x,y+h,r);ctx.arcTo(x,y+h,x,y,r);ctx.arcTo(x,y,x+w,y,r);ctx.closePath()}
function draw(time){ctx.imageSmoothingEnabled=false;ctx.fillStyle='#8cbb78';ctx.fillRect(0,0,VIEW_W,VIEW_H);
 if(!state)return
 const targetX=clamp(state.x-VIEW_W/2,0,world.W*S-VIEW_W),targetY=clamp(state.y-VIEW_H/2,0,world.H*S-VIEW_H);
 camera.x+=((targetX-camera.x)*.12);camera.y+=((targetY-camera.y)*.12);
 const x0=clamp(Math.floor(camera.x/S)-1,0,world.W-1),x1=clamp(Math.ceil((camera.x+VIEW_W)/S)+1,0,world.W-1),y0=clamp(Math.floor(camera.y/S)-1,0,world.H-1),y1=clamp(Math.ceil((camera.y+VIEW_H)/S)+1,0,world.H-1);
 for(let y=y0;y<=y1;y++)for(let x=x0;x<=x1;x++)tile(Math.floor(x*S-camera.x),Math.floor(y*S-camera.y),world.terrain[y*world.W+x]);
 // tiny environmental shimmer
 if(state.stage%2===0)glow(200,40,200,'#ffe9a61a');
 const entities=[];
 for(const b of world.buildings)entities.push({y:b.y*S,fn:()=>drawImage(b.kind,b.x*S,b.y*S,1.75)});
 for(const p of world.props)entities.push({y:p.y*S,fn:()=>drawImage(p.kind,p.x*S,p.y*S,2*p.s)});
 for(const p of world.people)entities.push({y:p.y*S,fn:()=>{
   const wiggle=Math.sin(time*.0016+(p.sprite*1.4))*.8;
   sprite(p.sprite,p.x*S,p.y*S+wiggle,(p.mission!==undefined&&p.mission===state.stage)?0:([0,1,2,0][p.sprite%4]),time/280%3|0,1.95);
   if(p.mission===state.stage){const sx=p.x*S-camera.x,sy=p.y*S-camera.y;
     glow(sx,sy-78,31,'#fce8a85a');ctx.save();ctx.font='bold 29px Arial';ctx.fillStyle='#f8d477';ctx.strokeStyle='#354b54';ctx.lineWidth=4;ctx.textAlign='center';ctx.strokeText('!',sx,sy-75+Math.sin(time*.004)*5);ctx.fillText('!',sx,sy-75+Math.sin(time*.004)*5);ctx.restore();niceLabel(p.name,sx,sy-93+Math.sin(time*.004)*3,true);
   }else if(p.bank){niceLabel('BANCO',p.x*S-camera.x,p.y*S-camera.y-71,false)}
 }});
 let followers=clamp(state.party-1,1,5);for(let i=0;i<followers;i++){
  const t=tracking[Math.min((i+1)*20,tracking.length-1)];entities.push({y:t.y-2,fn:()=>sprite((i+1)%10,t.x,t.y,state.dir,0,1.75)});
 }
 entities.push({y:state.y,fn:()=>{
   const bounce=Math.sin(time*.028)*(Object.values(keys).some(Boolean)?2:0);
   ctx.save();ctx.fillStyle='#fff4b685';ctx.beginPath();ctx.ellipse(state.x-camera.x,state.y-camera.y-2,23,9,0,0,Math.PI*2);ctx.fill();ctx.restore();
   sprite((state.stage%state.party)%10,state.x,state.y+bounce,state.dir,anim%3|0,2.1);
 }});
 entities.sort((a,b)=>a.y-b.y);for(const e of entities)e.fn();
 // subtle edge darkening (very light)
 const g=ctx.createLinearGradient(0,0,0,VIEW_H);g.addColorStop(0,'#162f490c');g.addColorStop(.7,'#ffffff00');g.addColorStop(1,'#142d381b');ctx.fillStyle=g;ctx.fillRect(0,0,VIEW_W,VIEW_H);
 // offscreen quest pointer
 const p=activeNPC(),sx=p.x*S-camera.x,sy=p.y*S-camera.y;
 if(sx<40||sy<62||sx>VIEW_W-40||sy>VIEW_H-45){const xx=clamp(sx,82,VIEW_W-82),yy=clamp(sy,82,VIEW_H-70);const angle=Math.atan2(sy-VIEW_H/2,sx-VIEW_W/2);ctx.save();ctx.translate(xx,yy);ctx.rotate(angle+Math.PI/2);ctx.fillStyle='#f9d481';ctx.strokeStyle='#2d4c56';ctx.lineWidth=4;ctx.beginPath();ctx.moveTo(0,-16);ctx.lineTo(12,11);ctx.lineTo(0,6);ctx.lineTo(-12,11);ctx.closePath();ctx.stroke();ctx.fill();ctx.restore()}
}
function drawMini(){mx.fillStyle='#a8c68b';mx.fillRect(0,0,288,154);if(!state)return;
 let fx=288/world.W,fy=154/world.H;
 for(let y=0;y<world.H;y++)for(let x=0;x<world.W;x++){const tileid=world.terrain[y*world.W+x];mx.fillStyle=tileid===6||tileid===7?'#4b6875':tileid===8?'#ddd9b6':tileid===4||tileid===5?'#dcc5a1':tileid===9?'#70b8c4':'#85b87e';mx.fillRect(x*fx,y*fy,Math.ceil(fx),Math.ceil(fy))}
 for(const b of world.buildings){mx.fillStyle='#294956';mx.fillRect((b.x-3.7)*fx,(b.y-5.4)*fy,7.4*fx,4.8*fy);mx.fillStyle='#f5dfab';mx.fillRect((b.x-3.1)*fx,(b.y-4.8)*fy,6.2*fx,3.5*fy)}
 const dot=(px,py,fill,r)=>{mx.beginPath();mx.arc(px*fx,py*fy,r,0,Math.PI*2);mx.fillStyle=fill;mx.fill();mx.strokeStyle='#263d48';mx.lineWidth=1;mx.stroke()};
 const dest=activeNPC();dot(27.3,20,'#fdf3c8',4);dot(dest.x,dest.y,'#ffdb65',5+Math.sin(performance.now()*.007)*.6);dot(state.x/S,state.y/S,'#55d6c6',5);}
function update(dt){if(!started||modalOpen||state.completed)return;
 let vx=0,vy=0;const left=keys.ArrowLeft||keys.a||keys.A,right=keys.ArrowRight||keys.d||keys.D,up=keys.ArrowUp||keys.w||keys.W,down=keys.ArrowDown||keys.s||keys.S;
 if(left)vx--;if(right)vx++;if(up)vy--;if(down)vy++;
 if(vx||vy){const norm=Math.hypot(vx,vy);vx/=norm;vy/=norm;let speed=188,dx=vx*speed*dt,dy=vy*speed*dt;
 if(vx<0)state.dir=1;else if(vx>0)state.dir=2;else if(vy<0)state.dir=3;else if(vy>0)state.dir=0;
 if(!world.collides(state.x+dx,state.y,11))state.x+=dx;
 if(!world.collides(state.x,state.y+dy,11))state.y+=dy;
 anim+=(dt*8);if(Math.hypot(state.x-tracking[0].x,state.y-tracking[0].y)>6)tracking.unshift({x:state.x,y:state.y});if(tracking.length>240)tracking.pop();
 }else anim=0;
 const p=nearestNPC();$('interactPrompt').classList.toggle('hidden',!p);if(p)$('promptText').textContent=p.bank?'Abrir banco':p.mission===state.stage?'Conversar com '+p.name:'Falar com '+p.name;
 let loc=state.y/S<21?'Bairro Norte':state.y/S<26?'Avenida Principal':state.x/S>33?'Praça Central':'Bairro Sul';$('locationTag').textContent='⌁ '+loc;const dest=activeNPC();$('targetDistance').textContent=Math.max(0,Math.round(Math.hypot(state.x-dest.x*S,state.y-dest.y*S)/S))+' passos';
}
function loop(time){const dt=Math.min((time-last)/1000,.04)||0;last=time;update(dt);if(state){draw(time);if(started&&Math.floor(time/200)!==Math.floor((time-dt*1000)/200))drawMini();}requestAnimationFrame(loop)}
window.addEventListener('keydown',e=>{
 const k=e.key.toLowerCase();
 if(['arrowup','arrowdown','arrowleft','arrowright',' ','b','m','f','j','h','tab'].includes(k))e.preventDefault();
 if(e.repeat&&['e','b','m','f','j','h','escape','tab'].includes(k))return;
 keys[e.key]=true;
 if(k==='f'){toggleFullscreen();return;}
 if(!started)return;
 if(k==='escape'){
  if(!modalOpen)showPause();else if(state.phase==='explore'&&!state.completed)closeModal();return;
 }
 if(modalOpen||state.completed||state.phase!=='explore')return;
 if(k==='e')interact();if(k==='b')showBank();if(k==='m')showMap();if(k==='j')showJournal();if(k==='h')showHelp();if(k==='tab')toggleStatus();
});
window.addEventListener('keyup',e=>{keys[e.key]=false});window.addEventListener('blur',()=>{for(const k in keys)keys[k]=false});
function bindTouch(){for(const b of document.querySelectorAll('[data-key]')){const k=b.dataset.key;b.addEventListener('pointerdown',e=>{e.preventDefault();try{b.setPointerCapture(e.pointerId)}catch{}keys[k]=true});for(const event of ['pointerup','pointercancel','lostpointercapture'])b.addEventListener(event,()=>{keys[k]=false})}$('touchAction').onclick=interact;}
$('soundBtn').onclick=()=>{soundOn=!soundOn;$('soundBtn').textContent=soundOn?'♫':'♪';$('soundBtn').title=soundOn?'Desativar sons':'Ativar sons';$('soundBtn').setAttribute('aria-label',$('soundBtn').title);if(soundOn)tone(880,.15);};
$('fullscreenBtn').onclick=toggleFullscreen;
$('pauseBtn').onclick=showPause;
$('statsBtn').onclick=()=>toggleStatus();
$('closeStatusBtn').onclick=()=>toggleStatus(false);
$('bankBtn').onclick=showBank;
$('mapBtn').onclick=showMap;
$('helpBtn').onclick=showHelp;
$('learnBtn').onclick=showLearning;
$('journalBtn').onclick=()=>{if(!started){showHelp();return;}showJournal()};
$('resetBtn').onclick=()=>{if(!started){intro();return}openModal(`<span class="modal-eyebrow">REINICIAR CAMPANHA</span><h2>Quer começar novamente?</h2><p>Suas escolhas atuais serão descartadas. O salvamento é automático neste navegador.</p><div class="button-line"><button class="primary-button" id="confirmReset">Sim, reiniciar</button><button class="secondary-button" id="cancelReset">Continuar jogando</button></div>`);$('confirmReset').onclick=()=>{try{localStorage.removeItem(STORAGE)}catch{}startGame(state.party)};$('cancelReset').onclick=()=>{if(state.completed)endGame();else if(state.phase==='final-plan')showFinalPlan();else closeModal()}};
resizeStage();bindTouch();intro();requestAnimationFrame(loop);
})();
