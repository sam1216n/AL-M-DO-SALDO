# Leia primeiro

A versão atual é **VALTIVA · Além do Saldo v0.3**. Abra `index.html` no navegador para jogar. Use `README.md` para conhecer os controles, o processo de publicação, o histórico e as mudanças implementadas. O arquivo `MANUAL.md` apresenta as regras para os alunos. Os registros de teste e prompts ficam em `docs/`.
