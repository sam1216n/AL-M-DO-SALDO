# Manual do jogador · VALTIVA — Além do Saldo v0.3

**Tipo:** aventura educativa 2D e gerenciamento financeiro. **Equipe:** 2 a 6 pessoas ou duplas, no mesmo aparelho. **Duração desejada:** 15 a 30 minutos; ainda não validada em playtest presencial.

## História e objetivo

Você vive em Vila Aurora e tem seis meses para se preparar para uma oportunidade de curso. Cada capítulo apresenta um dilema financeiro com diferentes alternativas e um desafio de Matemática. O grupo precisa tomar decisões e analisar seus impactos.

Para vencer ao final do sexto capítulo, sua equipe deve ter:

- **Reserva de R$ 250 ou mais**.
- **Dívidas de até R$ 250**.
- **Bem-estar simbólico de pelo menos 35 pontos**.

Caso alguma condição falhe, a equipe recebe o resultado da campanha e pode tentar outra estratégia. Não existe eliminação de jogadores durante a partida.

## Como jogar

1. Escolha de 2 a 6 pessoas no menu. O grupo joga cooperativamente. A cada novo capítulo, um jogador assume a decisão principal; o resto pode discutir as opções.
2. Explore Vila Aurora com **WASD** ou as **setas**. Siga o marcador dourado, observe o objetivo no canto da tela e encontre a pessoa correspondente.
3. Chegue perto da pessoa e pressione **E** (ou o botão de interação do celular).
4. Leia o dilema, avalie o orçamento e escolha uma alternativa entre as três disponíveis.
5. Observe a consequência financeira e responda ao desafio matemático. Se errar, aparecerá uma explicação antes da próxima etapa.
6. A cada mês seguinte, a simulação acrescenta **R$ 240 de renda** e desconta **R$ 135 de despesas essenciais**, com juros de **5% ao mês sobre a dívida remanescente**. As quantias são fictícias, estabelecidas para a dinâmica do jogo.
7. Use o banco digital (tecla **B** ou botão **BANCO**) para transferir dinheiro à reserva, retirar valores ou pagar dívidas. Você pode acessar o banco antes ou depois das missões.
8. Depois da sexta missão, haverá uma **última etapa de planejamento**. Organize o orçamento no banco e clique em **Concluir jornada** para verificar a vitória.

## Outros controles

- **M:** mapa da cidade.
- **J:** diário de escolhas e operações bancárias.
- **H:** instruções.
- **Tab:** painel financeiro detalhado.
- **F:** tela cheia, se autorizada pelo navegador.
- **Esc:** pausa e retorno à exploração; alguns navegadores utilizam Esc para sair da tela cheia.
- **Celular:** controles de direção e interação dentro do jogo.

## Conteúdos educativos

Os desafios abordam porcentagem, descontos, juros simples, juros compostos, orçamento, reserva financeira e comparação de alternativas. O indicador de bem-estar é **apenas uma abstração educativa**; não mede saúde real nem substitui avaliação profissional. A realidade financeira depende também de renda, oportunidades e condições sociais.

## Registro do professor

O projeto possui seis missões, ao menos três escolhas por missão, conclusão verificável, manual e ficha matemática. O multiplayer nesta versão é **local e compartilhado**: não há rede entre computadores. O jogo é automaticamente salvo no navegador usado para jogar.
