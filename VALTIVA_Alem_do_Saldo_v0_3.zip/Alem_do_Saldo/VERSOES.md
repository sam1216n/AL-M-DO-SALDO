# Evolução das versões e evidências

- **v0.2 — Pacote-base recebido.** Cópia preservada sem alterações em `historico/VALTIVA_v0.2_original.zip`. Foi a referência de código, sprites, regras, missões e economia.
- **v0.3 — Experiência imersiva.** Reconstrução da interface, tela cheia, UX, organização financeira final e documentação. Capturas em `docs/capturas/`.

## Publicar no GitHub

1. Crie um repositório para o projeto e envie os arquivos atuais da pasta `Alem_do_Saldo/`.
2. Faça um commit descritivo, por exemplo `feat: experiência imersiva e interface v0.3`.
3. Crie uma tag `v0.3` para fixar esta versão.
4. Publique um release com a distribuição ZIP e imagens da partida.
5. Repita para cada atualização. **Não altere retroativamente a tag v0.3** para parecer que funcionalidades futuras já existiam.
6. Para versões anteriores, publique apenas arquivos e registros que realmente possuir; não reconstitua histórico fictício.

## Registro escolar

Use `docs/prompts/` para a instrução original, ferramenta, data, resultado, testes e alterações humanas. Para apresentações, o ideal é mostrar a evolução com capturas reais de cada versão; este repositório não constitui, por si só, prova de participação de todos os integrantes.
