# VALTIVA · ALÉM DO SALDO v0.3

**Aventura 2D educativa em pixel art, para navegador.** Explore Vila Aurora, converse com personagens, faça escolhas financeiras e acompanhe o resultado de seis meses fictícios de planejamento. Projeto escolar em evolução — não é orientação financeira real.

## Abrir e jogar

1. Extraia o ZIP completo.
2. Abra o arquivo `Alem_do_Saldo/index.html` no Chrome, Edge ou Firefox atualizado.
3. Escolha **2 a 6 jogadores** e clique em **Começar aventura**. O navegador tentará abrir o jogo em tela cheia. Se não conseguir, o jogo continuará ocupando a área da página. Você também pode usar **F11** no computador para a tela cheia do navegador.
4. O grupo joga no **mesmo dispositivo**, alternando quem decide a cada capítulo. Não há multiplayer em computadores separados nesta versão.

Se preferir executar com um servidor local (recomendado para testes e futura publicação):

```bash
cd Alem_do_Saldo
python -m http.server 8000
```

Abra `http://localhost:8000` no navegador. Não é necessário instalar bibliotecas JavaScript, configurar API ou possuir conexão com a internet após carregar os arquivos.

## Controles

- **WASD / setas:** movimentar o personagem.
- **E:** interagir com moradores próximos.
- **B:** banco digital (guardar, retirar ou pagar dívidas).
- **M:** mapa completo, com destino, banco e sua posição.
- **J:** diário de decisões.
- **H:** ajuda.
- **Tab:** abrir ou fechar detalhes da jornada.
- **F:** alternar tela cheia, quando permitido pelo navegador.
- **Esc:** pausar ou fechar janelas de exploração; o navegador também pode usar Esc para sair da tela cheia.
- **Celular:** controle direcional na tela e botão **E / FALAR**.

## Objetivo

Conclua as seis missões com **ao menos R$ 250 na reserva**, **dívidas de até R$ 250** e **bem-estar simbólico de ao menos 35/100**. Ao final, há uma etapa para organizar os recursos antes do resultado. O saldo disponível **não é automaticamente a reserva**, pois guardar dinheiro faz parte da mecânica.

## Principais mudanças na v0.3

- Tela de abertura cinematográfica e jogo ocupando o viewport; solicitação de tela cheia após ação do jogador.
- Interface de aventura com indicadores compactos, objetivos e ações contextuais.
- Painel detalhado sob demanda; mini mapa acessível e mapa com imagem real da cidade.
- Canvas adaptável às proporções da tela, com câmera sem distorção do mapa.
- Feedback das consequências depois de escolhas, antes de iniciar o desafio matemático.
- Planejamento final, para evitar derrota inesperada quando havia dinheiro disponível ainda não transferido à reserva.
- Controles mobile, pausa, atalhos e preservação do salvamento v0.2 (`localStorage`, mesma chave).
- Histórico de versões, capturas e registro fiel das solicitações fornecidas pelo usuário.

## Código e arquitetura

```text
index.html          abertura, mundo, HUD, painéis e controles
immersive.css       layout imersivo e responsividade
src/world.js        terreno, edifícios, NPCs, colisões
src/game.js         estado, renderização Canvas, missões, economia, UI e salvamento
assets/             arte pixel e marca já existentes no projeto-base
make_assets.py      script original usado para gerar recursos de arte
MANUAL.md           regras para jogadores e professor
FICHA-MATEMATICA.md exemplos das fórmulas utilizadas no jogo
CHANGELOG.md        evolução e pendências
VERSOES.md          organização do histórico para o GitHub
docs/prompts/       solicitações reais registradas
historico/          cópia exata do ZIP original v0.2
```

As informações de jogo ficam **no navegador do dispositivo**, em `localStorage`. O projeto ainda **não possui contas, backend, salvamento em nuvem ou sincronização entre aparelhos**.

## GitHub Pages / futura plataforma VALTIVA

Publique **o conteúdo da pasta `Alem_do_Saldo/` na raiz de um repositório**. Ative GitHub Pages em *Settings → Pages → Deploy from a branch*, usando a branch principal e `/ (root)`. Os links de recursos são relativos; por isso, a mesma base poderá ser publicada posteriormente numa rota como `valtiva.com.br/jogos/alem-do-saldo/` (endereço apenas ilustrativo, não configurado).

Sugestão: use tags e GitHub Releases para que o professor encontre cada versão. O arquivo `historico/VALTIVA_v0.2_original.zip` preserva a versão anterior sem alterações.

## Limitações e próximas etapas

A v0.3 é uma **reconstrução de experiência/UI, não um remake gráfico completo**. O mapa, os sprites e as seis missões da v0.2 foram preservados como base. Ainda precisam de evolução: rotinas de NPCs, exploração significativa, diálogos ramificados, desafios matemáticos diretamente ligados às ações, áudio ambiente autoral, equilíbrio da economia, testes presenciais e validação da duração de 15–30 minutos. Consulte `CHANGELOG.md`.

**Autoria e colaboração:** VALTIVA, projeto escolar. Código v0.3 desenvolvido a partir do pacote v0.2 enviado pelo responsável pelo projeto, com assistência de IA documentada em `docs/prompts/`. Sem afirmar exclusividade sobre bibliotecas, fontes ou recursos preexistentes.
