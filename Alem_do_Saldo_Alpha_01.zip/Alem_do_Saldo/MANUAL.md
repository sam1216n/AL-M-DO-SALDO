# MANUAL DE REGRAS — Além do Saldo

**Objetivo:** viver uma curta jornada em Vila Aurora e aprender a planejar dinheiro, reconhecer o custo do crédito e lidar com pressão financeira.

## Participantes

De **2 a 6 jogadores ou duplas**, cooperando em uma mesma tela. O jogador responsável pela decisão muda a cada mês. Todos podem conversar antes de agir, e a equipe compartilha orçamento, dívidas e reserva.

## Preparação

Abra `index.html`, selecione a quantidade de participantes e comece. O grupo inicia com R$ 260 disponíveis, R$ 0 guardados, R$ 0 em dívidas e 70 pontos de bem-estar.

## Turno de jogo

1. Explore a cidade com as setas ou WASD.
2. Encontre o NPC sinalizado com indicador dourado, aproxime-se e pressione E (ou FALAR).
3. Analise as três opções e tome uma decisão. As alternativas que exigem mais dinheiro do que existe no caixa ficam indisponíveis.
4. Responda a um desafio matemático. Se acertar, o grupo recebe **R$ 30**. Se errar, verá a explicação e continuará.
5. Uma vez concluído o capítulo, avance para o mês seguinte.

Ao mudar de mês, entram R$ 240 de renda fictícia e são debitados R$ 135 de despesas essenciais, gerando **R$ 105 líquidos**. A dívida pendente aumenta em **5% a cada mês** por juros compostos, conforme a regra desta simulação. Os personagens também podem ganhar ou perder pontos de bem-estar de acordo com decisões e contexto.

## Banco

Aperte **B** ou converse com Gael na frente do Banco Aurora. Você pode guardar R$ 50/R$ 100, retirar R$ 50 ou quitar até R$ 100 de dívida, limitado ao saldo disponível e à dívida existente. Não há rendimento da reserva nesta versão.

## Vitória e derrota

Após **seis capítulos**, a equipe vence somente se cumprir as três metas: ter **pelo menos R$ 250 guardados**, terminar com **no máximo R$ 250 em dívida** e manter **bem-estar de 35 ou mais**. Se qualquer condição não for atendida, a campanha termina sem vitória, com um resumo das áreas a melhorar. A equipe pode reiniciar e testar outra estratégia.

## Conteúdos trabalhados

- Matemática: desconto percentual, juros simples, juros compostos, receita, despesa e organização orçamentária.
- Ciências da Natureza: explicações sobre hábitos de saúde, sono, estresse e bem-estar em contextos de pressão financeira.
- Projeto de vida: metas de estudo, escolhas e decisões de longo prazo.

*Aviso: os efeitos no indicador de bem-estar são simplificados para fins lúdicos. O endividamento não decorre apenas de hábitos individuais; condições sociais e eventos imprevistos também influenciam a vida financeira.*
