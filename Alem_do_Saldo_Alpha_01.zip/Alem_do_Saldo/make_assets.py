from PIL import Image, ImageDraw, ImageFont
from pathlib import Path
import random, math
random.seed(83)
out=Path(__file__).parent/'assets';out.mkdir(exist_ok=True)
C={ 'ink':'#26384a','grass':'#78b96e','grass2':'#8dcc7a','darkgrass':'#5d9b62','flower':'#ffe2a4', 'stone':'#e1ccb0','stone2':'#cab7a0','asphalt':'#455567','shadow':'#30475b','white':'#fff2d9','orange':'#f3b35e','rose':'#f18277','teal':'#58b8ad','blue':'#6b9fca'}

def rect(d,xy,color): d.rectangle(xy, fill=color)
def line(d,points,color,width=1): d.line(points,fill=color,width=width)

# tiles at 16x16 arranged in one row
T=16
tiles=Image.new('RGBA',(T*13,T),(0,0,0,0))
for idx in range(13):
 im=Image.new('RGBA',(T,T)); d=ImageDraw.Draw(im)
 if idx in [0,1,2,3]:
  d.rectangle((0,0,15,15),fill=['#78b96e','#80bf71','#70b268','#77b871'][idx]);rr=random.Random(idx+991)
  for i in range(12):
   x,y=rr.randrange(16),rr.randrange(16);d.point((x,y),fill=rr.choice(['#55975f','#9bcf77','#90c97c','#a4d787']))
  if idx==1:
   for x,y in [(4,5),(10,11)]:
    d.point((x-1,y), fill='#fff1bd');d.point((x+1,y), fill='#f4ac99');d.point((x,y-1), fill='#fff1bd');d.point((x,y+1), fill='#fff1bd');d.point((x,y),fill='#fdd069')
  if idx==2:
   d.ellipse((4,4,11,9),fill='#5c9e65'); d.rectangle((7,3,9,5),fill='#5c9e65')
 elif idx in [4,5]:
  d.rectangle((0,0,15,15),fill=['#e3cda7','#d6ba93'][idx-4]);d.line((0,0,15,0),fill='#eadcbd');d.line((0,8,15,8),fill='#bfa988');d.line((8,0,8,8),fill='#bfa988');d.line((3,8,3,15),fill='#bfa988')
  d.point((5,3),fill='#f1e0bb')
 elif idx==6:
  d.rectangle((0,0,15,15),fill='#4a5a6b');d.line((0,1,15,1),fill='#53687c');d.point((3,7),fill='#59697c');d.point((13,12),fill='#3f5062')
 elif idx==7:
  d.rectangle((0,0,15,15),fill='#4a5a6b');d.rectangle((6,0,10,15),fill='#f6d988');d.rectangle((7,0,9,15),fill='#fae5aa')
 elif idx==8:
  d.rectangle((0,0,15,15),fill='#4a5a6b');d.rectangle((0,5,15,10),fill='#f6dfb8')
 elif idx==9:
  d.rectangle((0,0,15,15),fill='#5faec0');d.line((0,5,7,5),fill='#8acecf');d.line((6,12,15,12),fill='#83c5c7');d.line((0,15,8,15),fill='#469ab1')
 elif idx==10:
  d.rectangle((0,0,15,15),fill='#a0c480');d.ellipse((1,1,14,14),fill='#96bd78');d.ellipse((4,4,9,8),fill='#b3d196')
 elif idx==11:
  d.rectangle((0,0,15,15),fill='#7eb175');d.rectangle((2,1,13,13),fill='#9fc785');d.point((6,5),fill='#c8dba6')
 elif idx==12:
  d.rectangle((0,0,15,15),fill='#b3d1b4');d.line((0,0,15,15),fill='#a0c3a7');d.line((15,0,0,15),fill='#cce0c0')
 tiles.alpha_composite(im,(idx*T,0))
tiles.save(out/'tiles.png')

# characters 10 palettes and 4 dirs x 3 animation frames, pix art
hair=['#383e55','#8d583f','#d7aa62','#3c3c46','#a85c49','#3b6170','#9a643e','#55396b','#404c58','#7e5b48']
skin=['#f2c7a3','#b67f60','#e6ae8b','#8e634d','#d99970','#deb18b','#a66f59','#edc59d','#c88d6e','#f0b794']
shirt=['#e87377','#61bdaf','#f2bd5e','#8c93d8','#f18f77','#5b9bcc','#c7ad69','#da84ab','#a3bc6a','#e29b50']
pants=['#414d67','#395468','#565274','#364558','#3d5262','#474a73','#435660','#514b68','#2d5c62','#3b596a']
SW,SH=24,32
atlas=Image.new('RGBA',(SW*3,SH*4*10),(0,0,0,0))
for person in range(10):
 for facing in range(4): # 0 down,1 left,2 right,3 up
  for frame in range(3):
   im=Image.new('RGBA',(SW,SH));d=ImageDraw.Draw(im)
   # pixel-art soft shadow under shoes
   d.ellipse((4,28,20,31),fill=(30,47,53,67))
   # legs animation
   stride=[0,2,-2][frame]
   rect(d,(7+stride,23,11+stride,29),pants[person]);rect(d,(14-stride,23,18-stride,29),pants[person]);rect(d,(6+stride,28,11+stride,29),'#26384a');rect(d,(14-stride,28,19-stride,29),'#26384a')
   # shirt and outline
   rect(d,(5,14,19,24),'#26384a');rect(d,(6,15,18,23),shirt[person]);rect(d,(6,21,18,22),'#ffffff33')
   # arms
   if facing in (0,3):
    rect(d,(3,15+max(0,stride//2),5,23),skin[person]);rect(d,(19,15+max(0,-stride//2),21,23),skin[person])
   else:
    rect(d,(4,16,6,23),skin[person]);rect(d,(19,17,21,24),skin[person])
   # head ears hair
   rect(d,(6,4,18,16),'#26384a');rect(d,(7,5,17,15),skin[person]);rect(d,(6,4,18,8),hair[person]);
   if person in [1,4,7]: # long hair
    rect(d,(5,7,7,14),hair[person]);rect(d,(17,7,19,14),hair[person])
   elif person in [2,5]:
    rect(d,(7,3,14,5),hair[person]);rect(d,(10,2,17,4),hair[person])
   if facing==0:
    rect(d,(9,10,10,11),'#26384a');rect(d,(15,10,16,11),'#26384a');rect(d,(12,13,13,13),'#be7f69')
   elif facing==1: rect(d,(7,10,8,11),'#26384a')
   elif facing==2: rect(d,(16,10,17,11),'#26384a')
   else:rect(d,(8,6,17,10),hair[person]);rect(d,(10,12,14,13),'#7a5448')
   # backpack on player 0
   if person==0 and facing==3:rect(d,(8,15,16,22),'#f7c768')
   atlas.alpha_composite(im,(frame*SW,(person*4+facing)*SH))
atlas.save(out/'characters.png')

# standalone decorative objects

def prop(name,w,h,drawer):
 im=Image.new('RGBA',(w,h));d=ImageDraw.Draw(im);drawer(d,w,h);im.save(out/(name+'.png'))

def tree(d,w,h,variant):
 cx=w//2
 d.ellipse((6,h-11,w-5,h-3), fill=(39,57,67,65))
 rect(d,(cx-4,h-26,cx+4,h-7),'#946747');rect(d,(cx-2,h-25,cx,h-8),'#b6875f')
 palette=[('#467f65','#69ab76','#91c989'),('#4a8683','#6bb8a6','#a9d7a8'),('#6f9369','#91bc69','#b7d48c')][variant]
 d.ellipse((6,12,w-7,h-20),fill=palette[0]);d.ellipse((1,20,w-14,h-26),fill=palette[0]);d.ellipse((14,5,w-1,h-31),fill=palette[0]);d.ellipse((5,8,w-9,h-30),fill=palette[1]);d.ellipse((9,4,w-12,h-36),fill=palette[1]);d.ellipse((8,15,w-24,h-40),fill=palette[2]);d.ellipse((19,10,w-12,h-40),fill=palette[2]);d.rectangle((20,19,22,21),fill='#d9e7b1');d.rectangle((10,28,12,29),fill='#d0dea6')
for i in range(3):prop('tree'+str(i),48,64,lambda d,w,h,i=i:tree(d,w,h,i))

def bench(d,w,h):
 d.ellipse((2,22,46,30), fill=(32,43,58,70));rect(d,(7,9,42,14),'#a76d52');rect(d,(7,15,42,19),'#bc8262');rect(d,(8,20,41,24),'#ca946d');rect(d,(10,23,13,29),'#3b4d59');rect(d,(37,23,40,29),'#3b4d59');rect(d,(7,10,42,11),'#e1ae76')
prop('bench',48,32,bench)

def lamp(d,w,h):
 d.ellipse((4,h-7,29,h-1),fill=(34,49,62,70));rect(d,(13,16,18,h-5),'#3c5265');rect(d,(14,18,15,h-7),'#76909b');rect(d,(7,12,25,17),'#334859');rect(d,(9,5,23,14),'#f9d68e');rect(d,(11,6,20,10),'#fff6bd');rect(d,(5,3,27,6),'#415b69');rect(d,(13,0,18,4),'#526c7b')
prop('lamp',32,64,lamp)

def flowerbed(d,w,h):
 d.ellipse((1,21,46,31),fill=(44,52,60,50));rect(d,(2,13,45,25),'#8a684d');rect(d,(4,12,43,21),'#ad8358');rect(d,(6,8,41,18),'#4c986e');
 for x,y,color in [(8,8,'#f2c65d'),(17,10,'#ffebc6'),(25,7,'#ed8b91'),(34,11,'#f6d47c'),(14,15,'#e99586'),(28,15,'#f4c8b6')]:
  d.rectangle((x,y,x+3,y+3),fill=color);d.point((x+1,y+1),fill='#fff0bf')
prop('flowerbed',48,32,flowerbed)

def fountain(d,w,h):
 d.ellipse((4,39,91,70),fill=(38,49,63,60));d.ellipse((0,27,95,65),fill='#677d86');d.ellipse((5,30,90,59),fill='#83c2c9');d.ellipse((12,35,83,54),fill='#4cabbc');d.ellipse((31,20,65,48),fill='#bdc5b3');d.ellipse((36,24,60,41),fill='#82bfcb');rect(d,(45,8,51,31),'#e4d8b6');d.arc((28,0,68,31),180,360,fill='#dcf8de',width=3);d.arc((36,1,60,22),180,360,fill='#f7f7d3',width=2)
prop('fountain',96,72,fountain)

def crate(d,w,h):
 d.ellipse((3,27,36,32),fill=(36,50,57,50));rect(d,(4,7,34,29),'#97694a');rect(d,(7,10,31,26),'#c18b5f');rect(d,(10,10,12,26),'#a36e51');rect(d,(25,10,27,26),'#a36e51');d.line((9,12,30,25),fill='#8a6047',width=2)
prop('crate',40,32,crate)

def scooter(d,w,h):
 d.ellipse((6,23,16,34),fill='#2e4053');d.ellipse((37,23,47,34),fill='#2e4053');d.ellipse((9,25,13,30),fill='#d8dcce');d.ellipse((40,25,44,30),fill='#d8dcce');d.polygon([(13,22),(27,8),(39,22)],fill='#f2b46d');d.rectangle((16,20,42,23),fill='#ce8468');d.line((40,21,40,10,46,10),fill='#3b485b',width=2);d.rectangle((23,5,34,8),fill='#5c9eac')
prop('scooter',54,40,scooter)

def mail(d,w,h):
 d.ellipse((3,38,37,46),fill=(32,47,60,60));rect(d,(5,14,34,42),'#5a89ba');rect(d,(7,11,32,18),'#76a6cd');rect(d,(9,22,29,25),'#e7ecdf');rect(d,(14,36,24,42),'#426d9e');rect(d,(5,42,9,46),'#344d61');rect(d,(30,42,34,46),'#344d61')
prop('mailbox',40,48,mail)

# Storefront buildings. All 144x112 at native pixel scale.
font_path='/usr/share/fonts/truetype/dejavu/DejaVuSansMono-Bold.ttf'
try: font=ImageFont.truetype(font_path,11)
except: font=ImageFont.load_default()
settings={
 'market':('MERCADO','#e7b26b','#bf715e','#e7d7a8','#d5ebd6'),
 'bank':('BANCO','#6f9fa6','#386b7f','#e1dabb','#badfdf'),
 'school':('ESCOLA','#cea3c1','#855d8e','#e6d5b6','#d4cee9'),
 'cafe':('CAFÉ','#e6a58f','#ad666a','#f1d8aa','#f8d0aa'),
 'workshop':('OFICINA','#8fb5a4','#558271','#d9d8bb','#c2dcda'),
 'home':('CASA','#c7a47e','#845d60','#efe0b8','#c6d0d1'),
 'park':('BIBLIO','#a8b8cf','#688ca7','#e7d9b2','#e3e2c7'),
}
for name,(label,facade,roof,sign,glass) in settings.items():
 im=Image.new('RGBA',(144,112));d=ImageDraw.Draw(im)
 # under building shadow
 d.ellipse((12,99,133,109),fill=(42,47,60,75))
 rect(d,(16,29,129,98),'#334859');rect(d,(19,31,126,96),facade)
 # brick details
 for y in [47,61,77,89]:
  d.line((21,y,123,y),fill='#ffffff29',width=1)
  for x in range(21+((y//14)%2)*11,124,22):d.line((x,y-1,x,y-4),fill=roof)
 # roof
 d.polygon([(8,30),(22,9),(121,9),(137,30)],fill='#334859');d.polygon([(12,29),(24,12),(120,12),(133,29)],fill=roof)
 rect(d,(14,29,131,35),'#334859');rect(d,(17,29,129,32),'#f0d79b')
 # sign
 rect(d,(38,17,105,33),'#344b5b');rect(d,(40,18,103,30),sign)
 text_box=d.textbbox((0,0),label,font=font);tx=(144-(text_box[2]-text_box[0]))//2
 d.text((tx,18),label,font=font,fill='#3b5062')
 # windows
 for x in [26,103]:
  rect(d,(x,49,x+19,78),'#354a5b');rect(d,(x+2,51,x+17,76),glass)
  rect(d,(x+5,52,x+8,60),'#f5f8db');rect(d,(x+3,64,x+17,66),'#82acb8')
  rect(d,(x+8,49,x+10,78),'#536776')
 # entrance
 rect(d,(57,57,87,99),'#354a5b');rect(d,(60,60,83,96),'#698e9c');rect(d,(64,61,79,93),'#a7c8c0');rect(d,(80,79,82,82),'#fff1b3')
 rect(d,(51,96,94,101),'#7c8f91');rect(d,(45,101,100,104),'#bac5af')
 # add characteristic
 if name=='bank':
  for x in [20,48,95,122]:rect(d,(x,35,x+3,48),'#f0ead1')
 if name=='market':
  for x in range(23,119,18):rect(d,(x,36,x+9,42),'#f9e2bb');rect(d,(x+9,36,x+17,42),'#e47c77')
 if name=='cafe':
  rect(d,(110,36,120,45),'#e9b25b');d.arc((108,35,124,48),0,180,fill='#fff0c7',width=2)
 if name=='workshop':
  rect(d,(47,37,96,44),'#344b5b');d.text((53,36),'AUTO',font=font,fill='#fff4c6')
 if name=='school':
  rect(d,(69,1,76,13),'#e1bb69');rect(d,(67,4,78,8),'#e1bb69')
 if name=='home':
  rect(d,(45,44,101,47),'#efbd85')
 if name=='park':
  rect(d,(35,35,109,39),'#f4e0a1')
 im.save(out/(name+'.png'))
print('assets written',len(list(out.iterdir())))
