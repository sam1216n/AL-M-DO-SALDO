(function(){
'use strict';
const SIZE=32,W=64,H=42;
const buildings=[
 {kind:'market',x:12,y:18.2,label:'Mercado do Sol'},
 {kind:'bank',x:24,y:18.2,label:'Banco Aurora'},
 {kind:'school',x:43,y:18.2,label:'Escola Municipal'},
 {kind:'park',x:55,y:18.2,label:'Biblioteca'},
 {kind:'cafe',x:12,y:37.5,label:'Café da Praça'},
 {kind:'workshop',x:26,y:37.5,label:'Oficina do Bento'},
 {kind:'home',x:44,y:37.5,label:'Casa da Família'},
];
const people=[
 {name:'Lia',place:'Mercado',x:12.2,y:20.0,sprite:1,mission:0,role:'Vendedora'},
 {name:'Bento',place:'Oficina',x:26,y:35.3,sprite:5,mission:1,role:'Mecânico'},
 {name:'Ravi',place:'Banco',x:23.3,y:20.1,sprite:6,mission:2,role:'Consultor'},
 {name:'Maya',place:'Café',x:12.1,y:35.2,sprite:4,mission:3,role:'Amiga'},
 {name:'Sol',place:'Biblioteca',x:55,y:20,sprite:7,mission:4,role:'Bibliotecária'},
 {name:'Professora Ana',place:'Escola',x:43,y:20,sprite:3,mission:5,role:'Professora'},
 {name:'Gael',place:'Banco',x:27.3,y:20,sprite:2,bank:true,role:'Atendente'},
 {name:'Nina',place:'Praça',x:39.8,y:29.8,sprite:8,flavor:'Essa cidade muda a cada escolha.'},
 {name:'Téo',place:'Praça',x:35.5,y:32.7,sprite:9,flavor:'A feira da escola está chegando!'},
 {name:'Rosa',place:'Praça',x:48,y:28,sprite:1,flavor:'Guardar um pouquinho todo mês ajuda.'},
];
const props=[];
const add=(kind,x,y,s=1)=>props.push({kind,x,y,s});
const treecoords=[
 [3,8],[8,10],[17,8],[32,8],[38,10],[47,7],[59,11],[4,17],[18,14],[36,13],[49,15],[61,17],
 [3,30],[7,33],[19,29],[33,36],[36,37],[52,30],[58,35],[61,29],[4,38],[17,39],[50,39],
 [5,4],[14,4],[23,5],[29,4],[41,4],[52,3],[60,5]
];
for(let i=0;i<treecoords.length;i++){let [x,y]=treecoords[i];add('tree'+(i%3),x,y,1)}
[[6,19],[17,20],[36,19],[49,20],[54,26],[18,35],[47,34]].forEach(([x,y])=>add('flowerbed',x,y,.88));
[[9,20],[38,33],[50,28],[21,35]].forEach(([x,y])=>add('bench',x,y,1));
[[6,20],[19,20],[38,20],[48,20],[58,20],[8,28],[20,28],[49,28],[59,28]].forEach(([x,y])=>add('lamp',x,y,1));
[[15,34],[31,33],[22,19]].forEach(([x,y])=>add('crate',x,y,.95));
add('scooter',30,19,.9);add('scooter',50,35,1);add('mailbox',45.5,20,1);add('fountain',38,33,1.15);
const terrain=new Uint8Array(W*H);
function random(x,y){const z=(x*92837111+y*689287499+1931189)>>>0;return ((z^(z>>>13))*1274126177>>>0)/4294967295}
for(let y=0;y<H;y++)for(let x=0;x<W;x++){
 let t=random(x,y)<.135?1:(random(y,x)<.07?2:0);
 // pedestrian paths and plazas
 if((y>=18&&y<=21)||(y>=25&&y<=27)||(y>=34&&y<=36)||(x>=10&&x<=14&&y>=18&&y<=37)||(x>=23&&x<=27&&y>=18&&y<=37)||(x>=41&&x<=45&&y>=18&&y<=37)||(x>=53&&x<=57&&y>=18&&y<=22)||(x>=34&&x<=42&&y>=28&&y<=35))t=((x+y)%7===0)?5:4;
 // road horizontal, vertical
 if((y>=22&&y<=24)||(x>=30&&x<=33))t=6;
 if(y===23&&x%5===0)t=7;
 if(x===31&&y%5===0)t=7;
 // intersections pedestrian crosswalk
 if(y>=22&&y<=24 && ((x>=10&&x<=13)||(x>=23&&x<=27)||(x>=41&&x<=45)||(x>=53&&x<=56)))t=8;
 if(x>=30&&x<=33&&((y>=18&&y<=20)||(y>=33&&y<=36)))t=8;
 // smooth isolated patches of stone
 if(x>35&&x<42&&y>27&&y<35)t=4;
 // water pond on far north east near library
 if(x>=57&&x<=63&&y>=2&&y<=6)t=9;
 terrain[y*W+x]=t;
}
const solids=[];
for(const b of buildings){const px=b.x*SIZE,py=b.y*SIZE;solids.push({x:px-109,y:py-155,w:218,h:130})}
for(const p of props){if(p.kind.startsWith('tree'))solids.push({x:p.x*SIZE-13,y:p.y*SIZE-20,w:26,h:18});}
// fountain blocks walking through center
solids.push({x:38*SIZE-40,y:33*SIZE-28,w:80,h:45});
function collides(x,y,r=13){
 if(x<r+8||y<r+5||x>W*SIZE-r-6||y>H*SIZE-r-6)return true;
 for(const s of solids){const nx=Math.max(s.x,Math.min(x,s.x+s.w)),ny=Math.max(s.y,Math.min(y,s.y+s.h));if((x-nx)**2+(y-ny)**2<(r*r))return true}
 return false;
}
window.AlemWorld={SIZE,W,H,terrain,buildings,props,people,collides};
})();
