# FICHA DE DEFESA MATEMÁTICA — Além do Saldo

**Projeto:** RPG digital sobre educação financeira e endividamento, MAP Matemática + Ciências da Natureza.

**Mecânica central:** O jogador faz escolhas com custos ou dívidas. O saldo, a poupança e o montante de dívidas são atualizados a cada decisão. Nos desafios, calcula valores e interpreta suas consequências.

**Juros simples (missões 2 e 6):** `J = C × i × t` e `M = C + J`. Ex.: R$ 100, 10% ao mês, 2 meses → J = R$ 20; M = R$ 120. Outro exemplo: R$ 300, 8% ao mês, 2 meses → M = R$ 348.

**Juros compostos (missão 3 e sistema de dívidas):** `M = C × (1 + i)^t`. Ex.: R$ 200, 5% ao mês, 2 meses → M = R$ 220,50. No jogo, as dívidas aumentam 5% por virada de mês sobre o saldo devedor, arredondadas para centavos.

**Porcentagem e desconto (missões 1 e 4):** `Preço final = preço inicial × (1 − taxa)`. Ex.: R$ 120 com 25% de desconto → R$ 90; R$ 150 com 20% → R$ 120.

**Orçamento (missão 5):** `Saldo = receita − despesas`. Ex.: R$ 380 − R$ 240 = R$ 140. Na simulação mensal, renda R$ 240 − gastos essenciais R$ 135 = R$ 105 líquidos.

**Gestão de recursos:** depósito transfere do caixa para a poupança sem criar dinheiro; quitação reduz caixa e dívida pelo mesmo valor. Escolhas têm custos diferentes. Questões corretas geram bônus lúdico de R$ 30, explicitado nas regras.

**Conexão com Ciências da Natureza:** decisões com pressão financeira dialogam com sono, estresse e hábitos de saúde por textos explicativos. O medidor de bem-estar é um recurso de jogo, não um índice clínico.

**Vitória:** poupança ≥ R$ 250, dívida ≤ R$ 250 e bem-estar ≥ 35 no fim do sexto capítulo. Todos os valores e taxas são hipotéticos, definidos para representar relações matemáticas em contexto educativo.
