# VALTIVA · ALÉM DO SALDO — Versão 0.2

## O que foi alterado

1. Identidade visual da VALTIVA incorporada à página do jogo e seus diálogos, usando a marca original.
2. Layout modernizado em desktop e mobile, mantendo a cidade em pixel art.
3. Inserido painel "Aprendizado da vez" com seis conceitos e explicações acessíveis.
4. Corrigida a continuidade da partida salva durante os desafios, evitando dupla aplicação de uma escolha ao recarregar a página.
5. Corrigida a forma de validar estados gravados em armazenamento local.
6. Tipografia, cores, botões, contrastes, cards, modal, mapa e barra de progresso harmonizados visualmente.

## Não incluído

- Multiplayer competitivo LAN/online (a base fornecida é cooperativa por turnos).
- Produto independente ÍRIS AI (planejamento em fase futura).
- Refatoração da lógica financeira em centavos inteiros; a base ainda usa valores numéricos arredondados a duas casas.

## Como abrir

Abra `index.html` em um navegador recente. Você pode continuar a campanha anterior, pois a chave de salvamento foi mantida. Use o botão "Entender o conceito" no novo painel didático.

## Testes recomendados

Iniciar 2-6 jogadores; movimentar com teclado e toque; conversar e completar missões; depositar/retirar/pagar; atualizar a aba após escolher uma resposta; recuperar a partida e concluir a campanha; checar responsividade em 375 px e desktop.
