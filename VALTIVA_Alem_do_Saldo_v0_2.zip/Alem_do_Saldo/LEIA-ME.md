# ALÉM DO SALDO — VALTIVA EDIÇÃO 0.2

**Um RPG 2D de escolhas, educação financeira e endividamento, com a identidade visual institucional VALTIVA.** Projeto escolar para *Trilhas da Juventude* — integração MAP Matemática e MAP Ciências da Natureza.

## Como jogar

1. Extraia o ZIP em uma pasta.
2. Abra `index.html` no navegador (Chrome, Edge ou Firefox). **Não é necessário instalar nada, usar servidor nem ter internet.**
3. Escolha de **2 a 6 jogadores** (multiplayer local cooperativo, em turnos, no mesmo dispositivo) e comece.
4. Siga o indicador dourado até o personagem da missão. O grupo decide qual opção escolher e responde ao desafio matemático.

**Teclado:** `WASD` ou `setas` para andar; `E` para interagir; `B` para abrir o banco; `M` para ver ajuda do mapa. No celular, use as setas e o botão **FALAR** sobrepostos ao jogo. 

**Objetivo:** ao terminar seis capítulos, ter pelo menos R$ 250 guardados, até R$ 250 de dívidas e bem-estar de 35 ou mais. A partida tem uma história curta; o tempo de conclusão depende do ritmo de exploração e discussão dos jogadores.

## O que foi implementado

- Uma cidade navegável com **7 fachadas ilustradas**, biblioteca, mercado, banco, escola, oficina, café, casas e praça.
- **19 arquivos de arte original em PNG**, incluindo um atlas de 10 personagens com 4 direções e 3 quadros de animação para cada direção; variações de paisagem e objetos.
- 6 missões de múltiplas escolhas com consequências financeiras e indicador de bem-estar.
- 6 questões matemáticas com cálculos e resolução explicada.
- Sistema de dívida com capitalização de **5% ao mês** sobre o saldo devedor (regra do jogo).
- Renda simulada mensal de R$ 240, despesas essenciais simuladas de R$ 135, e bônus de R$ 30 por desafio correto.
- Aplicativo bancário para guardar, retirar e pagar dívidas, minimapa, HUD e salvamento automático local.
- Multiplayer local cooperativo por revezamento: cada capítulo pertence a um jogador, com orçamento e objetivo coletivos.
- Sons simples sintetizados opcionais (no botão ♫).
- Textos de conexão com Ciências da Natureza sobre estresse financeiro, sono, rotina e bem-estar.

## Estrutura

```
index.html       Página inicial e interface do jogo
valtiva-theme.css  Identidade visual oficial da VALTIVA aplicada à interface
styles.css       Estilos da página, dos cartões e dos diálogos
src/world.js     Mapa, colisões, personagens e objetos do mundo
src/game.js      Jogo, movimentação, eventos, finanças e perguntas
assets/          Sprites PNG e animações originais
make_assets.py   Script para regerar/editar os sprites PNG
MANUAL.md        Regras completas para os jogadores
FICHA-MATEMATICA.md Demonstração curricular e fórmulas
```

## Próximas versões

- Mais animações, efeitos de partículas e trilha sonora própria.
- Refinar acessórios e diversidade visual dos personagens.
- Equilibrar o tempo médio e a dificuldade com testes na turma.
- Desenvolver a **ÍRIS AI** como produto separado da VALTIVA, futuramente. **A IA não faz parte deste jogo.**

## Observações importantes

- O modo de 2 a 6 jogadores é **cooperativo local por turnos**: não há controles separados simultâneos nem multiplayer pela internet.
- Os valores, taxas, trabalhos e cenários financeiros são hipotéticos e pedagógicos. O indicador de bem-estar não representa diagnóstico de saúde.
- Os sprites são produzidos pelo script `make_assets.py`, usando Pillow no computador de desenvolvimento; **o jogador não precisa de Python**.
- As fontes usam alternativas do sistema para funcionar sem conexão com a internet.
- Para publicar online, envie o conteúdo da pasta para um serviço de hospedagem estática. Não são necessárias chaves de API.

## Atualização 0.2 — identidade visual e qualidade

- Identidade VALTIVA com cores oficiais `#0D192B`, `#347EF5`, `#81E4D4`, fundo claro e tipografia Manrope/Inter com fontes alternativas do sistema.
- Logotipo institucional original incluído em `assets/valtiva-wordmark.png`.
- Painel de aprendizagem contextualizado em seis temas, com acesso a explicações dentro do jogo.
- Recuperação confiável dos estados intermediários (após escolher uma ação ou responder ao desafio) para evitar a repetição acidental de escolhas e prêmios após recarregar a página.
- Validação básica do salvamento local, melhorias na acessibilidade do diálogo e ajustes responsivos.
- Todo o mapa e os sprites originais foram preservados; nenhuma integração com IA, servidor ou multiplayer pela internet foi adicionada.

**Escopo:** esta edição usa a versão Alpha 0.1 como base. Se existir uma versão mais recente em outro repositório, é necessário trazer esse código para aplicar as mesmas mudanças sem perder progresso posterior.
